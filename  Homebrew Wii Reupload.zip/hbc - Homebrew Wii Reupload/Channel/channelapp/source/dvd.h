#ifndef _DVD_H_
#define _DVD_H_

#include <gctypes.h>

s32 WiiDVD_StopMotorAsync(void);
void WiiDVD_ShutDown(void);

#endif

